const appConfig= {
    port: process.env.PORT || 8080,
    hostUrl: process.env.HOST_URL || "http://localhost"
}

module.exports = appConfig